from config import *

from config_2 import*
from Bot import*

Bot = Cripto_Bot(api_key=api_key, api_secret=api_secret, cripto=CRIPTO, ref=REF, period=PERIOD, leverage=LEVERAGE,
                 sma_f=SMA_F,sma_s=SMA_S, side=SIDE, capital=CAPITAL)

Bot.run()