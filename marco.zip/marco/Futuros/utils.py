
import pandas as pd
import numpy as np
from typing import Tuple




def Get_Capital(result, ref):
    for i in range(len(result.assets)):
        if result.assets[i].asset == ref:
            return result.assets[i].marginBalance

def Get_Exchange_filters(result, S) -> Tuple:
    for i in range(len(result.symbols)):
        if result.symbols[i].symbol == S:
            minQty = float(result.symbols[i].filters[2].get('minQty'))
            stepSize = float(result.symbols[i].filters[2].get('stepSize'))
            maxQty = float(result.symbols[i].filters[2].get('maxQty'))
            return minQty, stepSize, maxQty

def Calculate_max_Decimal_Qty(stepSize):
    max_decimal_quantity=0
    a = 10
    while stepSize*a<1:
      a = a*10**max_decimal_quantity
      max_decimal_quantity += 1
    return max_decimal_quantity

def Calculate_Qty(price, money, minQty, maxQty, maxDeciamlQty):

    Q = money / price
    if (Q < minQty or Q > maxQty):
        return False
    Q = np.round(Q, maxDeciamlQty)
    return Q

def Crossover(MF, MS):
    if (MF[0] < MS[0] and MF[1] >= MS[1]):
        return True
    else:
        return False

